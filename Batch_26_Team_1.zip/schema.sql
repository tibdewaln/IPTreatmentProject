--Create a schema name 'hospital'

--After runnnig the application exceute this insert statements

-- create table users(
-- id int,
-- password varchar(255),
-- user_name varchar(255),
-- primary key (id));

insert into users values(1, 'pwd', 'admin');

insert into specialists (specialist_id, area_of_expertise, contact_number, experience_in_years, name) values(1, 0, 9945672345, 10, 'Dr Riya' );
insert into specialists (specialist_id, area_of_expertise, contact_number, experience_in_years, name) values(2, 0, 8876523457, 8, 'Dr Karan' );
insert into specialists (specialist_id, area_of_expertise, contact_number, experience_in_years, name) values(3, 1, 9422467465, 7, 'Dr Harsh' );
insert into specialists (specialist_id, area_of_expertise, contact_number, experience_in_years, name) values(4, 1, 756842689, 11, 'Dr Shreya' );


insert into packages (pid, cost, treatment_duration, treatment_package_name) values (101, 25000, 4, 'Package 1');
insert into packages (pid, cost, treatment_duration, treatment_package_name) values (102, 30000, 6, 'Package 2');
insert into packages (pid, cost, treatment_duration, treatment_package_name) values (103, 40000, 4, 'Package 1');
insert into packages (pid, cost, treatment_duration, treatment_package_name) values (104, 50000, 6, 'Package 2');


insert into package_detail_test_details (package_detail_pid, test_details) values (101, 'OPT1');
insert into package_detail_test_details (package_detail_pid, test_details) values (101, 'OPT2');
insert into package_detail_test_details (package_detail_pid, test_details) values (102, 'OPT3');
insert into package_detail_test_details (package_detail_pid, test_details) values (102, 'OPT4');
insert into package_detail_test_details (package_detail_pid, test_details) values (103, 'UPT1');
insert into package_detail_test_details (package_detail_pid, test_details) values (103, 'UPT2');
insert into package_detail_test_details (package_detail_pid, test_details) values (104, 'UPT3');
insert into package_detail_test_details (package_detail_pid, test_details) values (104, 'UPT4');


insert into iptreatmentpackage (treatment_package_id, ailment_category, package) values(1, 0, 101);
insert into iptreatmentpackage (treatment_package_id, ailment_category, package) values(2, 0, 102);
insert into iptreatmentpackage (treatment_package_id, ailment_category, package) values(3, 1, 103);
insert into iptreatmentpackage (treatment_package_id, ailment_category, package) values(4, 1, 104);

insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (1, 'Apollo Munich', 'Surgical Protection', 16442, 3);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (2, 'Max Rupa', 'Health Companion Family Floater', 15194, 4);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (3, 'Star Health', 'Extra Care', 25460, 5);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (4, 'Policy Bazaar', 'Critical Illness', 15200, 2);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (5, 'Religare', 'Silver Health Plan for Senior Citizens', 45975, 6);

