--Create a schema name 'hospital'

--After runnnig the application the table will automatically get created
then exceute the insert statements in schema.sql